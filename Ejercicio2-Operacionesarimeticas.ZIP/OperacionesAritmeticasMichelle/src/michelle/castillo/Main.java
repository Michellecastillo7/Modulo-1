/*
 *Crear un programa que imprima en consola todas las operaciones aritméticas
 *de dos números enteros (suma, resta, multiplicación, divición, mod)
 */

package michelle.castillo;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        try (Scanner scanner = new Scanner(System.in)) {
            System.out.print("Ingresa el primer número: ");
            int num1 = scanner.nextInt();
            
            System.out.print("Ingresa el segundo número: ");
            int num2 = scanner.nextInt();
            
            int suma = num1 + num2;
            int resta = num1 - num2;
            int multiplicacion = num1 * num2;
            int division = num2 != 0 ? num1 / num2 : 0;
            int modulo = num2 != 0 ? num1 % num2 : 0;
            
            System.out.println("\nResultados de las operaciones:");
            System.out.println("Suma: " + suma);
            System.out.println("Resta: " + resta);
            System.out.println("Multiplicación: " + multiplicacion);
            System.out.println("División: " + division);
            System.out.println("Módulo: " + modulo);
        }
    }
}
