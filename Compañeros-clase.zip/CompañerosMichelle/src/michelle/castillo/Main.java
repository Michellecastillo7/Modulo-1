/*
 *Crear un arrelo que guarde e imprima 10 nombres de tus compañeros de la clase
 */

package michelle.castillo;

public class Main {
    public static void main(String[] args) {
        String[] compañeros = {
            "Alejandra Lopez",
            "Yaritza Padilla",
            "Edwin Gomez",
            "Jorge Dubon",
            "Edgar Licona",
            "Josue Sandoval",
            "Gerardo Galindo",
            "Cesar Raudales",
            "Jose Alfaro",
            "Michelle Castillo"
        };

        System.out.println("Lista de compañeros de clase:");
        for (String nombre : compañeros) {
            System.out.println(nombre);
        }
    }
}
