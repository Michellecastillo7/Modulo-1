/*
 * Crear un arreglo multidimensional que guarde más datos personales tus compañeros de clase (nombre, apellido, carrera, lugarTrabajo),
tomando como referencia de la información colocada en el foro Conociendonos. Llenar 5 registros Ejemplo:
 */
package michelle.castillo;

public class Main {
    public static void main(String[] args) {
        String[][] compañeros = {
            {"Alejandra", "Lopez", "Ingeniería en Sistemas", "Google"},
            {"Yaritza", "Padilla", "Administración de Empresas", "Banco Atlántida"},
            {"Edwin", "Gomez", "Contaduría Pública", "Deloitte"},
            {"Jorge", "Dubon", "Ingeniería Electrónica", "Tesla"},
            {"Michelle", "Castillo", "Computación", "Microsoft"}
        };

        System.out.println("Lista de compañeros de clase:");
        System.out.println("--------------------------------------");
        System.out.printf("%-10s %-10s %-25s %-15s\n", "Nombre", "Apellido", "Carrera", "Lugar de Trabajo");
        System.out.println("--------------------------------------");

        for (String[] compañero : compañeros) {
            System.out.printf("%-10s %-10s %-25s %-15s\n", compañero[0], compañero[1], compañero[2], compañero[3]);
        }
    }
}
