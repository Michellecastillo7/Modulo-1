/*
 * Crear un programa que imprima en consola un nombre de estudiante, una nota y 
 *una etiqueta que diga Aprobado o Reprobado, dependiendo del valor de la nota que tenga.
 */
package michelle.castillo;

public class Main {
    public static void main(String[] args) {
        String[] nombres = {
            "Alejandra Lopez", "Yaritza Padilla", "Edwin Gomez", 
            "Jorge Dubon", "Edgar Licona", "Josue Sandoval", 
            "Gerardo Galindo", "Cesar Raudales", "Jose Alfaro", "Michelle Castillo"
        };

        int[] notas = {85, 60, 74, 90, 40, 55, 77, 95, 66, 88};

        // Imprimir los resultados
        System.out.println("Resultados de los estudiantes:\n");
        
        for (int i = 0; i < nombres.length; i++) {
            String estado = (notas[i] >= 70) ? "Aprobado" : "Reprobado";
            System.out.println(nombres[i]);
            System.out.println(notas[i]);
            System.out.println(estado);
            System.out.println("-----------------------");
        }
    }
}
